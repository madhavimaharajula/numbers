number-sentinel
