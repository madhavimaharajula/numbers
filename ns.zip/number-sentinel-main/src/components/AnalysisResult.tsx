import React from 'react';
import { Shield, MapPin, Phone, AlertTriangle, CheckCircle, XCircle, Download, Clock } from 'lucide-react';
import { AnalysisData } from '../types/analysis';

interface AnalysisResultProps {
  data: AnalysisData;
}

const AnalysisResult: React.FC<AnalysisResultProps> = ({ data }) => {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'LOW': return 'text-green-600 bg-green-100';
      case 'MEDIUM': return 'text-yellow-600 bg-yellow-100';
      case 'HIGH': return 'text-orange-600 bg-orange-100';
      case 'CRITICAL': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getRiskIcon = (level: string) => {
    switch (level) {
      case 'LOW': return <CheckCircle className="h-5 w-5" />;
      case 'MEDIUM': return <AlertTriangle className="h-5 w-5" />;
      case 'HIGH': return <AlertTriangle className="h-5 w-5" />;
      case 'CRITICAL': return <XCircle className="h-5 w-5" />;
      default: return <Shield className="h-5 w-5" />;
    }
  };

  const downloadReport = () => {
    const report = {
      phoneNumber: data.phoneNumber,
      analysisTime: data.analysisTime,
      riskLevel: data.riskLevel,
      riskPercentage: data.riskPercentage,
      carrier: data.carrier,
      location: data.location,
      fraudIndicators: data.fraudIndicators,
      recommendations: data.recommendations
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `number-analysis-${data.phoneNumber.replace(/[^0-9]/g, '')}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Risk Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Risk Analysis</h3>
          <button
            onClick={downloadReport}
            className="flex items-center space-x-2 px-3 py-1 text-sm text-blue-600 hover:text-blue-700 border border-blue-200 hover:border-blue-300 rounded-md transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="text-center">
            <div className="relative inline-block">
              <div className="w-32 h-32 mx-auto">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="10"
                    fill="none"
                    className="text-gray-200"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="40"
                    stroke="currentColor"
                    strokeWidth="10"
                    fill="none"
                    strokeDasharray={`${2.51 * data.riskPercentage} 251.2`}
                    className={data.riskPercentage > 70 ? 'text-red-500' : 
                             data.riskPercentage > 40 ? 'text-orange-500' :
                             data.riskPercentage > 20 ? 'text-yellow-500' : 'text-green-500'}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-2xl font-bold text-gray-900">{data.riskPercentage}%</span>
                </div>
              </div>
            </div>
            <div className="mt-4">
              <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(data.riskLevel)}`}>
                {getRiskIcon(data.riskLevel)}
                <span className="ml-2">{data.riskLevel} RISK</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Phone Number</p>
                <p className="font-medium text-gray-900">{data.phoneNumber}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Analysis Time</p>
                <p className="font-medium text-gray-900">{data.analysisTime}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Shield className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-600">Confidence</p>
                <p className="font-medium text-gray-900">{data.confidence}%</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Carrier Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <Phone className="h-5 w-5 mr-2 text-blue-600" />
          Carrier Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-gray-600">Carrier</p>
            <p className="font-medium text-gray-900">{data.carrier.name}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Network Type</p>
            <p className="font-medium text-gray-900">{data.carrier.type}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Technology</p>
            <p className="font-medium text-gray-900">{data.carrier.technology.join(', ')}</p>
          </div>
        </div>
      </div>

      {/* Location Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
          <MapPin className="h-5 w-5 mr-2 text-purple-600" />
          Location Details
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-gray-600">State</p>
            <p className="font-medium text-gray-900">{data.location.state}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">City</p>
            <p className="font-medium text-gray-900">{data.location.city}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Telecom Circle</p>
            <p className="font-medium text-gray-900">{data.location.circle}</p>
          </div>
          <div>
            <p className="text-sm text-gray-600">Area Code</p>
            <p className="font-medium text-gray-900">{data.location.areaCode}</p>
          </div>
        </div>
      </div>

      {/* Fraud Indicators */}
      {data.fraudIndicators.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2 text-orange-600" />
            Fraud Indicators
          </h3>
          <div className="space-y-3">
            {data.fraudIndicators.map((indicator, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className={`mt-0.5 w-2 h-2 rounded-full ${
                  indicator.severity === 'HIGH' ? 'bg-red-500' :
                  indicator.severity === 'MEDIUM' ? 'bg-yellow-500' : 'bg-green-500'
                }`}></div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="font-medium text-gray-900">{indicator.indicator}</span>
                    <span className={`px-2 py-0.5 text-xs rounded-full ${
                      indicator.severity === 'HIGH' ? 'bg-red-100 text-red-800' :
                      indicator.severity === 'MEDIUM' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-green-100 text-green-800'
                    }`}>
                      {indicator.severity}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{indicator.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recommendations */}
      {data.recommendations.length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
            Recommendations
          </h3>
          <ul className="space-y-2">
            {data.recommendations.map((recommendation, index) => (
              <li key={index} className="flex items-start space-x-3">
                <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                <span className="text-gray-700">{recommendation}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default AnalysisResult;