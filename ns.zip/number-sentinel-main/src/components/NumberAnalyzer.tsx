import React, { useState } from 'react';
import { Phone, Search } from 'lucide-react';
import { AnalysisData } from '../types/analysis';
import { analyzePhoneNumber } from '../utils/phoneAnalysis';

interface NumberAnalyzerProps {
  onAnalysis: (result: AnalysisData) => void;
  onAnalyzing: (analyzing: boolean) => void;
}

const NumberAnalyzer: React.FC<NumberAnalyzerProps> = ({ onAnalysis, onAnalyzing }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!phoneNumber.trim()) {
      setError('Please enter a phone number');
      return;
    }

    onAnalyzing(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const result = analyzePhoneNumber(phoneNumber.trim());
      onAnalysis(result);
    } catch (err) {
      setError('Analysis failed. Please try again.');
    } finally {
      onAnalyzing(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPhoneNumber(value);
    if (error) setError('');
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Phone className="h-6 w-6 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900">Number Analysis</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </label>
          <input
            type="text"
            id="phoneNumber"
            value={phoneNumber}
            onChange={handleInputChange}
            placeholder="Enter Indian phone number (e.g., +91 98765 43210)"
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
          />
          {error && (
            <p className="mt-2 text-sm text-red-600">{error}</p>
          )}
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors flex items-center justify-center space-x-2"
        >
          <Search className="h-5 w-5" />
          <span>Analyze Number</span>
        </button>
      </form>

      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <h4 className="text-sm font-semibold text-gray-900 mb-2">Supported Formats</h4>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• +91 98765 43210</li>
          <li>• 91 9876543210</li>
          <li>• 9876543210</li>
          <li>• +91-98765-43210</li>
        </ul>
      </div>
    </div>
  );
};

export default NumberAnalyzer;