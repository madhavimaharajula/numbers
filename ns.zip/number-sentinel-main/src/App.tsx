import React, { useState } from 'react';
import { Shield, Phone, MapPin, AlertTriangle, CheckCircle, XCircle, Search, Download } from 'lucide-react';
import NumberAnalyzer from './components/NumberAnalyzer';
import AnalysisResult from './components/AnalysisResult';
import { AnalysisData } from './types/analysis';

function App() {
  const [analysisResult, setAnalysisResult] = useState<AnalysisData | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalysis = (result: AnalysisData) => {
    setAnalysisResult(result);
  };

  const handleAnalyzing = (analyzing: boolean) => {
    setIsAnalyzing(analyzing);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Shield className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Number Sentinel</h1>
              <span className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-full">INDIA</span>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Advanced Fraud Detection</span>
              <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Advanced Phone Number <span className="text-blue-600">Fraud Analysis</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Analyze phone numbers for fraud risk using comprehensive Indian telecom databases, 
            carrier verification, and location intelligence.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center">
              <Phone className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">2.5M+</p>
                <p className="text-gray-600">Numbers Analyzed</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">94.2%</p>
                <p className="text-gray-600">Accuracy Rate</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center">
              <AlertTriangle className="h-8 w-8 text-red-600" />
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">180K+</p>
                <p className="text-gray-600">Fraud Detected</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
            <div className="flex items-center">
              <MapPin className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-2xl font-bold text-gray-900">All 36</p>
                <p className="text-gray-600">States/UTs Covered</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Analysis Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Section */}
          <div className="lg:col-span-1">
            <NumberAnalyzer 
              onAnalysis={handleAnalysis} 
              onAnalyzing={handleAnalyzing}
            />
          </div>

          {/* Results Section */}
          <div className="lg:col-span-2">
            {isAnalyzing ? (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
                <div className="flex items-center justify-center space-x-3">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <span className="text-lg text-gray-600">Analyzing number...</span>
                </div>
                <div className="mt-4 space-y-2">
                  <div className="h-2 bg-gray-200 rounded-full">
                    <div className="h-2 bg-blue-600 rounded-full animate-pulse" style={{ width: '45%' }}></div>
                  </div>
                  <p className="text-sm text-gray-500 text-center">Checking carrier databases and fraud patterns...</p>
                </div>
              </div>
            ) : analysisResult ? (
              <AnalysisResult data={analysisResult} />
            ) : (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
                <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Ready to Analyze</h3>
                <p className="text-gray-600">Enter a phone number to begin fraud risk analysis</p>
              </div>
            )}
          </div>
        </div>

        {/* Features Section */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Why Choose Number Sentinel?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
              <CheckCircle className="h-10 w-10 text-green-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Real-time Database</h4>
              <p className="text-gray-600">Updated carrier information and fraud patterns from Indian telecom providers.</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
              <Shield className="h-10 w-10 text-blue-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Advanced Analytics</h4>
              <p className="text-gray-600">Multi-factor risk assessment using AI and machine learning algorithms.</p>
            </div>
            <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-100">
              <MapPin className="h-10 w-10 text-purple-600 mb-4" />
              <h4 className="text-lg font-semibold text-gray-900 mb-2">Location Intelligence</h4>
              <p className="text-gray-600">Precise location detection using area codes and telecom circle data.</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;