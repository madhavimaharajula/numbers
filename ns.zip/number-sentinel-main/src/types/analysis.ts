export interface AnalysisData {
  phoneNumber: string;
  isValid: boolean;
  riskPercentage: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  carrier: {
    name: string;
    type: 'GSM' | 'CDMA';
    technology: string[];
  };
  location: {
    state: string;
    city: string;
    circle: string;
    areaCode: string;
  };
  fraudIndicators: {
    indicator: string;
    severity: 'LOW' | 'MEDIUM' | 'HIGH';
    description: string;
  }[];
  recommendations: string[];
  analysisTime: string;
  confidence: number;
}